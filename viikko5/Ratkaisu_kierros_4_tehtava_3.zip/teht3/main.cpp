#include <iostream>
#include <stack>

using namespace std;



int main(){


    stack<int> st;
    int n;
    cout<<"Syota alkuluku: ";
    cin>>n;

    int i = 2;
    while (n != 1) {
        if (n % i == 0) {
            st.push(i);
            while (n % i == 0) {
                n = n / i;
            }
        }
        i++;
    }
 
    // Print value of stack st
    while (!st.empty()) {
 
        printf("%d ", st.top());
        st.pop();
    }


    

    return EXIT_SUCCESS;
}